import smtplib
import imaplib
import email as email_lib


#--------------------Email Sender--------------------#
# sender_email = input("SENDER EMAIL: ")
# receiver_email = input("RECEIVER EMAIL:")

# subject = input("SUBJECT: ")
# message = input("MESSAGE: ")

# text = f"Subject: {subject}\n\n{message}"

# server = smtplib.SMTP("smtp.gmail.com", 587)
# server.starttls()

# server.login(sender_email, "lszc wmzo hxog ewjb")

# server.sendmail(sender_email, receiver_email, text)

# print("Email has been sent to " + receiver_email)



#--------------------Email Reader--------------------#
sender_email = input("ENTER YOUR EMAIL: ")
password = "lszc wmzo hxog ewjb"

print("\nChecking inbox...\n")

imap = imaplib.IMAP4_SSL("imap.gmail.com")

imap.login(sender_email, "lszc wmzo hxog ewjb")

imap.select("inbox")

# Search all emails
status, messages = imap.search(None, "UNSEEN")

mail_ids = messages[0].split()

if not mail_ids:
    print("Koi unread email nahi hai inbox mein.")
else:
    print(f"Total unread emails: {len(mail_ids)}\n")


# Last 5 emails read karo
for i in mail_ids[-5:]:
    status, msg_data = imap.fetch(i, "(RFC822)")

    for response_part in msg_data:
        if isinstance(response_part, tuple):
            msg = email_lib.message_from_bytes(response_part[1])

            subject = msg["subject"]
            from_ = msg["from"]

            print("From:", from_)
            print("Subject:", subject)
            

            # Email body
            if msg.is_multipart():
                for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            body = part.get_payload(decode=True).decode(errors="replace")
                            print("Body:", body)
                            break
                else:
                    body = msg.get_payload(decode=True).decode(errors="replace")
                    print("Body:", body)

                # Email ko Seen mark karo aur foran apply karo
                imap.store(i, '+FLAGS', '\\Seen')
                imap.expunge()  # Flag permanently apply karta hai

                print("-" * 50)
        


imap.close()
imap.logout()